import { test, expect } from './fixtures.mjs';
test('REQ-999: deliberately failing sample', async () => { expect(1).toBe(2); });
